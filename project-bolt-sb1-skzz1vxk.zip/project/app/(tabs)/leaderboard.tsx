import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Trophy, Medal, Crown, Star, ChevronUp, ChevronDown } from 'lucide-react-native';

interface Player {
  id: string;
  name: string;
  rank: number;
  rating: number;
  wins: number;
  losses: number;
  winRate: number;
  favoriteHero: string;
  avatar: string;
  tier: string;
  division: number;
}

const players: Player[] = [
  {
    id: '1',
    name: 'DragonSlayer99',
    rank: 1,
    rating: 2850,
    wins: 147,
    losses: 23,
    winRate: 86.5,
    favoriteHero: 'Dragon Warrior',
    avatar: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
    tier: 'Mythic',
    division: 5,
  },
  {
    id: '2',
    name: 'ShadowMaster',
    rank: 2,
    rating: 2790,
    wins: 134,
    losses: 31,
    winRate: 81.2,
    favoriteHero: 'Shadow Assassin',
    avatar: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
    tier: 'Mythic',
    division: 4,
  },
  {
    id: '3',
    name: 'IceQueen',
    rank: 3,
    rating: 2745,
    wins: 128,
    losses: 27,
    winRate: 82.6,
    favoriteHero: 'Frost Mage',
    avatar: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
    tier: 'Mythic',
    division: 3,
  },
  {
    id: '4',
    name: 'ThunderBolt',
    rank: 4,
    rating: 2680,
    wins: 115,
    losses: 35,
    winRate: 76.7,
    favoriteHero: 'Storm Archer',
    avatar: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
    tier: 'Mythic',
    division: 2,
  },
  {
    id: '5',
    name: 'IronWall',
    rank: 5,
    rating: 2620,
    wins: 108,
    losses: 42,
    winRate: 72.0,
    favoriteHero: 'Iron Guardian',
    avatar: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
    tier: 'Mythic',
    division: 1,
  },
  {
    id: '6',
    name: 'HolyLight',
    rank: 6,
    rating: 2550,
    wins: 102,
    losses: 38,
    winRate: 72.9,
    favoriteHero: 'Divine Healer',
    avatar: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
    tier: 'Legend',
    division: 5,
  },
  {
    id: '7',
    name: 'NightHawk',
    rank: 7,
    rating: 2480,
    wins: 95,
    losses: 45,
    winRate: 67.9,
    favoriteHero: 'Shadow Assassin',
    avatar: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
    tier: 'Legend',
    division: 4,
  },
  {
    id: '8',
    name: 'FireStorm',
    rank: 8,
    rating: 2420,
    wins: 89,
    losses: 41,
    winRate: 68.5,
    favoriteHero: 'Dragon Warrior',
    avatar: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
    tier: 'Legend',
    division: 3,
  },
];

export default function LeaderboardScreen() {
  const [selectedTab, setSelectedTab] = useState<'global' | 'friends'>('global');
  const [timeFilter, setTimeFilter] = useState<'daily' | 'weekly' | 'season'>('season');

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'Mythic':
        return ['#F59E0B', '#D97706'];
      case 'Legend':
        return ['#8B5CF6', '#7C3AED'];
      case 'Epic':
        return ['#3B82F6', '#2563EB'];
      default:
        return ['#6B7280', '#4B5563'];
    }
  };

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown size={24} color="#F59E0B" />;
    if (rank <= 3) return <Trophy size={24} color="#C0C0C0" />;
    if (rank <= 10) return <Medal size={24} color="#CD7F32" />;
    return <Star size={24} color="#64748B" />;
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1E293B', '#0F172A']}
        style={styles.header}>
        <Text style={styles.headerTitle}>Leaderboard</Text>
        <Text style={styles.headerSubtitle}>Top Players Rankings</Text>
      </LinearGradient>

      {/* Tab Selector */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tabButton,
            selectedTab === 'global' && styles.tabButtonActive,
          ]}
          onPress={() => setSelectedTab('global')}>
          <Text style={[
            styles.tabText,
            selectedTab === 'global' && styles.tabTextActive,
          ]}>
            Global
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tabButton,
            selectedTab === 'friends' && styles.tabButtonActive,
          ]}
          onPress={() => setSelectedTab('friends')}>
          <Text style={[
            styles.tabText,
            selectedTab === 'friends' && styles.tabTextActive,
          ]}>
            Friends
          </Text>
        </TouchableOpacity>
      </View>

      {/* Time Filter */}
      <View style={styles.timeFilterContainer}>
        {['daily', 'weekly', 'season'].map((filter) => (
          <TouchableOpacity
            key={filter}
            style={[
              styles.timeFilterButton,
              timeFilter === filter && styles.timeFilterButtonActive,
            ]}
            onPress={() => setTimeFilter(filter as any)}>
            <Text style={[
              styles.timeFilterText,
              timeFilter === filter && styles.timeFilterTextActive,
            ]}>
              {filter.charAt(0).toUpperCase() + filter.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Top 3 Podium */}
      <View style={styles.podiumContainer}>
        <View style={styles.podium}>
          {/* 2nd Place */}
          <View style={styles.podiumPlace}>
            <LinearGradient
              colors={getTierColor(players[1].tier)}
              style={[styles.podiumAvatar, { height: 60 }]}>
              <Image source={{ uri: players[1].avatar }} style={styles.avatarImage} />
            </LinearGradient>
            <View style={[styles.podiumBase, styles.secondPlace]}>
              <Text style={styles.podiumRank}>2</Text>
            </View>
            <Text style={styles.podiumName}>{players[1].name}</Text>
            <Text style={styles.podiumRating}>{players[1].rating}</Text>
          </View>

          {/* 1st Place */}
          <View style={[styles.podiumPlace, { marginTop: -20 }]}>
            <Crown size={20} color="#F59E0B" style={styles.crownIcon} />
            <LinearGradient
              colors={getTierColor(players[0].tier)}
              style={[styles.podiumAvatar, { height: 80 }]}>
              <Image source={{ uri: players[0].avatar }} style={styles.avatarImage} />
            </LinearGradient>
            <View style={[styles.podiumBase, styles.firstPlace]}>
              <Text style={styles.podiumRank}>1</Text>
            </View>
            <Text style={styles.podiumName}>{players[0].name}</Text>
            <Text style={styles.podiumRating}>{players[0].rating}</Text>
          </View>

          {/* 3rd Place */}
          <View style={styles.podiumPlace}>
            <LinearGradient
              colors={getTierColor(players[2].tier)}
              style={[styles.podiumAvatar, { height: 60 }]}>
              <Image source={{ uri: players[2].avatar }} style={styles.avatarImage} />
            </LinearGradient>
            <View style={[styles.podiumBase, styles.thirdPlace]}>
              <Text style={styles.podiumRank}>3</Text>
            </View>
            <Text style={styles.podiumName}>{players[2].name}</Text>
            <Text style={styles.podiumRating}>{players[2].rating}</Text>
          </View>
        </View>
      </View>

      {/* Rankings List */}
      <ScrollView style={styles.rankingsList}>
        {players.slice(3).map((player) => (
          <View key={player.id} style={styles.playerCard}>
            <LinearGradient
              colors={['rgba(30, 41, 59, 0.8)', 'rgba(15, 23, 42, 0.8)']}
              style={styles.playerCardGradient}>
              
              <View style={styles.playerRank}>
                {getRankIcon(player.rank)}
                <Text style={styles.rankNumber}>{player.rank}</Text>
              </View>

              <LinearGradient
                colors={getTierColor(player.tier)}
                style={styles.playerAvatar}>
                <Image source={{ uri: player.avatar }} style={styles.avatarImage} />
              </LinearGradient>

              <View style={styles.playerInfo}>
                <Text style={styles.playerName}>{player.name}</Text>
                <View style={styles.tierContainer}>
                  <Text style={styles.tierText}>{player.tier} {player.division}</Text>
                </View>
                <Text style={styles.favoriteHero}>{player.favoriteHero}</Text>
              </View>

              <View style={styles.playerStats}>
                <View style={styles.ratingContainer}>
                  <Text style={styles.ratingNumber}>{player.rating}</Text>
                  <View style={styles.ratingChange}>
                    <ChevronUp size={12} color="#10B981" />
                    <Text style={styles.ratingChangeText}>+25</Text>
                  </View>
                </View>
                
                <View style={styles.winRateContainer}>
                  <Text style={styles.winRateText}>{player.winRate}%</Text>
                  <Text style={styles.recordText}>
                    {player.wins}W / {player.losses}L
                  </Text>
                </View>
              </View>
            </LinearGradient>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 24,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.7)',
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    marginHorizontal: 8,
    alignItems: 'center',
  },
  tabButtonActive: {
    backgroundColor: '#F59E0B',
  },
  tabText: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 16,
    fontWeight: '500',
  },
  tabTextActive: {
    color: 'white',
    fontWeight: 'bold',
  },
  timeFilterContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  timeFilterButton: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    marginRight: 8,
  },
  timeFilterButtonActive: {
    backgroundColor: 'rgba(245, 158, 11, 0.3)',
  },
  timeFilterText: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 12,
    fontWeight: '500',
  },
  timeFilterTextActive: {
    color: '#F59E0B',
    fontWeight: 'bold',
  },
  podiumContainer: {
    paddingHorizontal: 16,
    paddingVertical: 24,
  },
  podium: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'flex-end',
  },
  podiumPlace: {
    alignItems: 'center',
    marginHorizontal: 16,
  },
  crownIcon: {
    position: 'absolute',
    top: -10,
    zIndex: 10,
  },
  podiumAvatar: {
    width: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  avatarImage: {
    width: '90%',
    height: '90%',
    borderRadius: 25,
    resizeMode: 'cover',
  },
  podiumBase: {
    width: 60,
    justifyContent: 'center',
    alignItems: 'center',
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    marginBottom: 8,
  },
  firstPlace: {
    height: 80,
    backgroundColor: '#F59E0B',
  },
  secondPlace: {
    height: 60,
    backgroundColor: '#C0C0C0',
  },
  thirdPlace: {
    height: 40,
    backgroundColor: '#CD7F32',
  },
  podiumRank: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  podiumName: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  podiumRating: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 12,
    marginTop: 2,
  },
  rankingsList: {
    flex: 1,
    paddingHorizontal: 16,
  },
  playerCard: {
    marginBottom: 12,
    borderRadius: 12,
    overflow: 'hidden',
  },
  playerCardGradient: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  playerRank: {
    alignItems: 'center',
    marginRight: 16,
    minWidth: 40,
  },
  rankNumber: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 4,
  },
  playerAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  playerInfo: {
    flex: 1,
  },
  playerName: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  tierContainer: {
    marginBottom: 2,
  },
  tierText: {
    color: '#F59E0B',
    fontSize: 12,
    fontWeight: '600',
  },
  favoriteHero: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 12,
  },
  playerStats: {
    alignItems: 'flex-end',
  },
  ratingContainer: {
    alignItems: 'center',
    marginBottom: 4,
  },
  ratingNumber: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  ratingChange: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingChangeText: {
    color: '#10B981',
    fontSize: 10,
    fontWeight: 'bold',
  },
  winRateContainer: {
    alignItems: 'flex-end',
  },
  winRateText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: 'bold',
  },
  recordText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 10,
  },
});