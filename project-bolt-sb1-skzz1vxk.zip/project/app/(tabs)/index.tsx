import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Text,
  ImageBackground,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  runOnJS,
} from 'react-native-reanimated';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import { LinearGradient } from 'expo-linear-gradient';
import { Sword, Shield, Zap, Heart } from 'lucide-react-native';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

interface Hero {
  id: string;
  name: string;
  health: number;
  maxHealth: number;
  mana: number;
  maxMana: number;
  level: number;
  experience: number;
  gold: number;
  x: number;
  y: number;
}

interface Minion {
  id: string;
  x: number;
  y: number;
  health: number;
  team: 'blue' | 'red';
  target: { x: number; y: number };
}

export default function BattleScreen() {
  const [gameStarted, setGameStarted] = useState(false);
  const [hero, setHero] = useState<Hero>({
    id: '1',
    name: 'Warrior',
    health: 100,
    maxHealth: 100,
    mana: 50,
    maxMana: 50,
    level: 1,
    experience: 0,
    gold: 500,
    x: screenWidth / 2,
    y: screenHeight - 150,
  });
  
  const [minions, setMinions] = useState<Minion[]>([]);
  const [abilities, setAbilities] = useState({
    skill1: { cooldown: 0, maxCooldown: 5000 },
    skill2: { cooldown: 0, maxCooldown: 8000 },
    skill3: { cooldown: 0, maxCooldown: 12000 },
  });

  const heroX = useSharedValue(hero.x);
  const heroY = useSharedValue(hero.y);
  const mapOffsetX = useSharedValue(0);
  const mapOffsetY = useSharedValue(0);

  // Initialize minions
  useEffect(() => {
    if (gameStarted) {
      const initialMinions: Minion[] = [];
      for (let i = 0; i < 6; i++) {
        initialMinions.push({
          id: `minion-${i}`,
          x: 50 + Math.random() * 100,
          y: 50 + i * 80,
          health: 30,
          team: 'red',
          target: { x: screenWidth - 100, y: screenHeight - 200 },
        });
      }
      setMinions(initialMinions);
    }
  }, [gameStarted]);

  // Ability cooldown system
  useEffect(() => {
    const interval = setInterval(() => {
      setAbilities(prev => ({
        skill1: {
          ...prev.skill1,
          cooldown: Math.max(0, prev.skill1.cooldown - 100),
        },
        skill2: {
          ...prev.skill2,
          cooldown: Math.max(0, prev.skill2.cooldown - 100),
        },
        skill3: {
          ...prev.skill3,
          cooldown: Math.max(0, prev.skill3.cooldown - 100),
        },
      }));
    }, 100);

    return () => clearInterval(interval);
  }, []);

  // Hero movement gesture
  const panGesture = Gesture.Pan()
    .onUpdate((event) => {
      const newX = Math.max(25, Math.min(screenWidth - 25, event.x));
      const newY = Math.max(50, Math.min(screenHeight - 200, event.y));
      
      heroX.value = withTiming(newX, { duration: 200 });
      heroY.value = withTiming(newY, { duration: 200 });
      
      runOnJS(setHero)(prev => ({ ...prev, x: newX, y: newY }));
    });

  const heroAnimatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: heroX.value - 25 },
      { translateY: heroY.value - 25 },
    ],
  }));

  const useAbility = (abilityKey: keyof typeof abilities) => {
    if (abilities[abilityKey].cooldown > 0) return;
    
    setAbilities(prev => ({
      ...prev,
      [abilityKey]: {
        ...prev[abilityKey],
        cooldown: prev[abilityKey].maxCooldown,
      },
    }));

    // Ability effects
    switch (abilityKey) {
      case 'skill1':
        // Attack ability
        setHero(prev => ({ ...prev, experience: prev.experience + 10 }));
        break;
      case 'skill2':
        // Heal ability
        setHero(prev => ({ 
          ...prev, 
          health: Math.min(prev.maxHealth, prev.health + 30),
          mana: Math.max(0, prev.mana - 20),
        }));
        break;
      case 'skill3':
        // Ultimate ability
        setHero(prev => ({ 
          ...prev, 
          experience: prev.experience + 25,
          mana: Math.max(0, prev.mana - 30),
        }));
        break;
    }
  };

  const startGame = () => {
    setGameStarted(true);
  };

  if (!gameStarted) {
    return (
      <View style={styles.container}>
        <LinearGradient
          colors={['#1E40AF', '#3B82F6', '#60A5FA']}
          style={styles.menuBackground}>
          <View style={styles.menuContent}>
            <Text style={styles.gameTitle}>LEGENDS ARENA</Text>
            <Text style={styles.gameSubtitle}>Mobile MOBA Battle</Text>
            
            <View style={styles.heroPreview}>
              <View style={styles.heroCard}>
                <LinearGradient
                  colors={['#F59E0B', '#D97706']}
                  style={styles.heroIcon}>
                  <Sword size={32} color="white" />
                </LinearGradient>
                <Text style={styles.heroName}>Warrior</Text>
                <Text style={styles.heroDescription}>Melee Fighter</Text>
              </View>
            </View>

            <TouchableOpacity style={styles.playButton} onPress={startGame}>
              <LinearGradient
                colors={['#F59E0B', '#D97706']}
                style={styles.playButtonGradient}>
                <Text style={styles.playButtonText}>START BATTLE</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </LinearGradient>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ImageBackground
        source={{ uri: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg' }}
        style={styles.gameMap}
        blurRadius={2}>
        
        {/* Game Map Overlay */}
        <View style={styles.mapOverlay} />
        
        {/* Minions */}
        {minions.map((minion) => (
          <View
            key={minion.id}
            style={[
              styles.minion,
              {
                left: minion.x - 15,
                top: minion.y - 15,
                backgroundColor: minion.team === 'red' ? '#DC2626' : '#2563EB',
              },
            ]}>
            <View style={styles.minionHealthBar}>
              <View 
                style={[
                  styles.minionHealthFill,
                  { width: `${(minion.health / 30) * 100}%` },
                ]} 
              />
            </View>
          </View>
        ))}

        {/* Hero */}
        <GestureDetector gesture={panGesture}>
          <Animated.View style={[styles.hero, heroAnimatedStyle]}>
            <LinearGradient
              colors={['#3B82F6', '#1E40AF']}
              style={styles.heroCircle}>
              <Sword size={24} color="white" />
            </LinearGradient>
            <View style={styles.heroHealthBar}>
              <View 
                style={[
                  styles.heroHealthFill,
                  { width: `${(hero.health / hero.maxHealth) * 100}%` },
                ]} 
              />
            </View>
          </Animated.View>
        </GestureDetector>

        {/* Lane Markers */}
        <View style={styles.topLane} />
        <View style={styles.middleLane} />
        <View style={styles.bottomLane} />

        {/* UI Overlays */}
        <View style={styles.topUI}>
          <View style={styles.scoreBoard}>
            <Text style={styles.scoreText}>Level {hero.level}</Text>
            <Text style={styles.scoreText}>Gold: {hero.gold}</Text>
            <Text style={styles.scoreText}>EXP: {hero.experience}/100</Text>
          </View>
        </View>

        {/* Hero Stats */}
        <View style={styles.heroStats}>
          <View style={styles.statBar}>
            <Heart size={16} color="#DC2626" />
            <View style={styles.healthBar}>
              <View 
                style={[
                  styles.healthFill,
                  { width: `${(hero.health / hero.maxHealth) * 100}%` },
                ]} 
              />
            </View>
            <Text style={styles.statText}>{hero.health}/{hero.maxHealth}</Text>
          </View>
          <View style={styles.statBar}>
            <Zap size={16} color="#3B82F6" />
            <View style={styles.manaBar}>
              <View 
                style={[
                  styles.manaFill,
                  { width: `${(hero.mana / hero.maxMana) * 100}%` },
                ]} 
              />
            </View>
            <Text style={styles.statText}>{hero.mana}/{hero.maxMana}</Text>
          </View>
        </View>

        {/* Ability Buttons */}
        <View style={styles.abilityPanel}>
          <TouchableOpacity
            style={[
              styles.abilityButton,
              abilities.skill1.cooldown > 0 && styles.abilityButtonDisabled,
            ]}
            onPress={() => useAbility('skill1')}
            disabled={abilities.skill1.cooldown > 0}>
            <Sword size={24} color={abilities.skill1.cooldown > 0 ? '#64748B' : 'white'} />
            {abilities.skill1.cooldown > 0 && (
              <Text style={styles.cooldownText}>
                {Math.ceil(abilities.skill1.cooldown / 1000)}
              </Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.abilityButton,
              abilities.skill2.cooldown > 0 && styles.abilityButtonDisabled,
            ]}
            onPress={() => useAbility('skill2')}
            disabled={abilities.skill2.cooldown > 0}>
            <Heart size={24} color={abilities.skill2.cooldown > 0 ? '#64748B' : 'white'} />
            {abilities.skill2.cooldown > 0 && (
              <Text style={styles.cooldownText}>
                {Math.ceil(abilities.skill2.cooldown / 1000)}
              </Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.abilityButton,
              abilities.skill3.cooldown > 0 && styles.abilityButtonDisabled,
            ]}
            onPress={() => useAbility('skill3')}
            disabled={abilities.skill3.cooldown > 0}>
            <Zap size={24} color={abilities.skill3.cooldown > 0 ? '#64748B' : 'white'} />
            {abilities.skill3.cooldown > 0 && (
              <Text style={styles.cooldownText}>
                {Math.ceil(abilities.skill3.cooldown / 1000)}
              </Text>
            )}
          </TouchableOpacity>
        </View>

        {/* Mini-map */}
        <View style={styles.miniMap}>
          <View style={styles.miniMapBorder}>
            <View style={[
              styles.miniMapHero,
              {
                left: (hero.x / screenWidth) * 80,
                top: (hero.y / screenHeight) * 60,
              },
            ]} />
            {minions.map((minion) => (
              <View
                key={`mini-${minion.id}`}
                style={[
                  styles.miniMapMinion,
                  {
                    left: (minion.x / screenWidth) * 80,
                    top: (minion.y / screenHeight) * 60,
                    backgroundColor: minion.team === 'red' ? '#DC2626' : '#2563EB',
                  },
                ]}
              />
            ))}
          </View>
        </View>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  menuBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuContent: {
    alignItems: 'center',
    padding: 32,
  },
  gameTitle: {
    fontSize: 48,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 4,
  },
  gameSubtitle: {
    fontSize: 18,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
    marginBottom: 48,
  },
  heroPreview: {
    marginBottom: 48,
  },
  heroCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    backdropFilter: 'blur(10px)',
  },
  heroIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  heroName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  heroDescription: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.7)',
  },
  playButton: {
    borderRadius: 25,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  playButtonGradient: {
    paddingHorizontal: 48,
    paddingVertical: 16,
  },
  playButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  gameMap: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  mapOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
  },
  hero: {
    position: 'absolute',
    width: 50,
    height: 50,
    zIndex: 100,
  },
  heroCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#F59E0B',
  },
  heroHealthBar: {
    position: 'absolute',
    bottom: -8,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: 'rgba(220, 38, 38, 0.3)',
    borderRadius: 2,
  },
  heroHealthFill: {
    height: '100%',
    backgroundColor: '#DC2626',
    borderRadius: 2,
  },
  minion: {
    position: 'absolute',
    width: 30,
    height: 30,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  minionHealthBar: {
    position: 'absolute',
    bottom: -6,
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 1,
  },
  minionHealthFill: {
    height: '100%',
    backgroundColor: '#10B981',
    borderRadius: 1,
  },
  topLane: {
    position: 'absolute',
    top: 100,
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: 'rgba(59, 130, 246, 0.5)',
  },
  middleLane: {
    position: 'absolute',
    top: screenHeight / 2,
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: 'rgba(59, 130, 246, 0.5)',
  },
  bottomLane: {
    position: 'absolute',
    bottom: 200,
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: 'rgba(59, 130, 246, 0.5)',
  },
  topUI: {
    position: 'absolute',
    top: 50,
    left: 16,
    right: 16,
    zIndex: 200,
  },
  scoreBoard: {
    backgroundColor: 'rgba(15, 23, 42, 0.8)',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  scoreText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  heroStats: {
    position: 'absolute',
    bottom: 140,
    left: 16,
    right: 16,
    zIndex: 200,
  },
  statBar: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  healthBar: {
    flex: 1,
    height: 8,
    backgroundColor: 'rgba(220, 38, 38, 0.3)',
    borderRadius: 4,
    marginHorizontal: 8,
  },
  healthFill: {
    height: '100%',
    backgroundColor: '#DC2626',
    borderRadius: 4,
  },
  manaBar: {
    flex: 1,
    height: 8,
    backgroundColor: 'rgba(59, 130, 246, 0.3)',
    borderRadius: 4,
    marginHorizontal: 8,
  },
  manaFill: {
    height: '100%',
    backgroundColor: '#3B82F6',
    borderRadius: 4,
  },
  statText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
    minWidth: 50,
    textAlign: 'right',
  },
  abilityPanel: {
    position: 'absolute',
    bottom: 20,
    right: 16,
    flexDirection: 'column',
    zIndex: 200,
  },
  abilityButton: {
    width: 60,
    height: 60,
    backgroundColor: 'rgba(30, 41, 59, 0.9)',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 2,
    borderColor: '#F59E0B',
  },
  abilityButtonDisabled: {
    backgroundColor: 'rgba(30, 41, 59, 0.5)',
    borderColor: '#64748B',
  },
  cooldownText: {
    position: 'absolute',
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  miniMap: {
    position: 'absolute',
    top: 120,
    right: 16,
    width: 100,
    height: 80,
    zIndex: 200,
  },
  miniMapBorder: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.8)',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#334155',
    position: 'relative',
  },
  miniMapHero: {
    position: 'absolute',
    width: 4,
    height: 4,
    backgroundColor: '#3B82F6',
    borderRadius: 2,
  },
  miniMapMinion: {
    position: 'absolute',
    width: 2,
    height: 2,
    borderRadius: 1,
  },
});