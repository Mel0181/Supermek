import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Settings as SettingsIcon, Volume2, VolumeX, Smartphone, User, Shield, CircleHelp as HelpCircle, LogOut, Bell, Gamepad2, Palette, Globe, Star } from 'lucide-react-native';

interface Setting {
  id: string;
  title: string;
  description?: string;
  type: 'toggle' | 'action' | 'navigation';
  icon: React.ReactNode;
  value?: boolean;
  action?: () => void;
}

export default function SettingsScreen() {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [vibrationEnabled, setVibrationEnabled] = useState(true);

  const gameSettings: Setting[] = [
    {
      id: 'sound',
      title: 'Sound Effects',
      description: 'Enable game sound effects',
      type: 'toggle',
      icon: soundEnabled ? <Volume2 size={20} color="#F59E0B" /> : <VolumeX size={20} color="#6B7280" />,
      value: soundEnabled,
      action: () => setSoundEnabled(!soundEnabled),
    },
    {
      id: 'music',
      title: 'Background Music',
      description: 'Enable background music',
      type: 'toggle',
      icon: <Volume2 size={20} color="#F59E0B" />,
      value: musicEnabled,
      action: () => setMusicEnabled(!musicEnabled),
    },
    {
      id: 'notifications',
      title: 'Push Notifications',
      description: 'Receive game updates and notifications',
      type: 'toggle',
      icon: <Bell size={20} color="#F59E0B" />,
      value: notificationsEnabled,
      action: () => setNotificationsEnabled(!notificationsEnabled),
    },
    {
      id: 'vibration',
      title: 'Haptic Feedback',
      description: 'Enable vibration for actions',
      type: 'toggle',
      icon: <Smartphone size={20} color="#F59E0B" />,
      value: vibrationEnabled,
      action: () => setVibrationEnabled(!vibrationEnabled),
    },
  ];

  const accountSettings: Setting[] = [
    {
      id: 'profile',
      title: 'Profile Settings',
      description: 'Edit your profile and avatar',
      type: 'navigation',
      icon: <User size={20} color="#F59E0B" />,
      action: () => Alert.alert('Profile', 'Profile settings coming soon!'),
    },
    {
      id: 'privacy',
      title: 'Privacy & Security',
      description: 'Manage your privacy settings',
      type: 'navigation',
      icon: <Shield size={20} color="#F59E0B" />,
      action: () => Alert.alert('Privacy', 'Privacy settings coming soon!'),
    },
    {
      id: 'language',
      title: 'Language',
      description: 'Change app language',
      type: 'navigation',
      icon: <Globe size={20} color="#F59E0B" />,
      action: () => Alert.alert('Language', 'Language settings coming soon!'),
    },
    {
      id: 'theme',
      title: 'Theme Settings',
      description: 'Customize app appearance',
      type: 'navigation',
      icon: <Palette size={20} color="#F59E0B" />,
      action: () => Alert.alert('Theme', 'Theme settings coming soon!'),
    },
  ];

  const supportSettings: Setting[] = [
    {
      id: 'help',
      title: 'Help & Support',
      description: 'Get help and contact support',
      type: 'navigation',
      icon: <HelpCircle size={20} color="#F59E0B" />,
      action: () => Alert.alert('Help', 'Visit our support center at support@legendsarena.com'),
    },
    {
      id: 'rate',
      title: 'Rate the Game',
      description: 'Leave a review on the app store',
      type: 'action',
      icon: <Star size={20} color="#F59E0B" />,
      action: () => Alert.alert('Rate', 'Thank you for your support! Redirecting to app store...'),
    },
    {
      id: 'logout',
      title: 'Sign Out',
      description: 'Sign out of your account',
      type: 'action',
      icon: <LogOut size={20} color="#DC2626" />,
      action: () => Alert.alert(
        'Sign Out',
        'Are you sure you want to sign out?',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Sign Out', style: 'destructive' },
        ]
      ),
    },
  ];

  const renderSettingItem = (setting: Setting) => (
    <TouchableOpacity
      key={setting.id}
      style={styles.settingItem}
      onPress={setting.action}>
      <LinearGradient
        colors={['rgba(30, 41, 59, 0.8)', 'rgba(15, 23, 42, 0.8)']}
        style={styles.settingItemGradient}>
        
        <View style={styles.settingIcon}>
          {setting.icon}
        </View>

        <View style={styles.settingContent}>
          <Text style={styles.settingTitle}>{setting.title}</Text>
          {setting.description && (
            <Text style={styles.settingDescription}>{setting.description}</Text>
          )}
        </View>

        {setting.type === 'toggle' && (
          <Switch
            value={setting.value}
            onValueChange={setting.action}
            trackColor={{ false: '#374151', true: '#F59E0B' }}
            thumbColor={setting.value ? '#FFFFFF' : '#9CA3AF'}
          />
        )}

        {setting.type === 'navigation' && (
          <View style={styles.navigationIndicator}>
            <Text style={styles.navigationText}>›</Text>
          </View>
        )}
      </LinearGradient>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1E293B', '#0F172A']}
        style={styles.header}>
        <SettingsIcon size={32} color="#F59E0B" />
        <Text style={styles.headerTitle}>Settings</Text>
        <Text style={styles.headerSubtitle}>Customize your experience</Text>
      </LinearGradient>

      <ScrollView style={styles.content}>
        {/* Player Info Card */}
        <View style={styles.playerCard}>
          <LinearGradient
            colors={['#F59E0B', '#D97706']}
            style={styles.playerCardGradient}>
            <View style={styles.playerAvatar}>
              <Gamepad2 size={32} color="white" />
            </View>
            <View style={styles.playerInfo}>
              <Text style={styles.playerName}>DragonSlayer99</Text>
              <Text style={styles.playerLevel}>Level 25 • Mythic Tier</Text>
              <Text style={styles.playerStats}>1,247 Battles • 82% Win Rate</Text>
            </View>
          </LinearGradient>
        </View>

        {/* Game Settings */}
        <View style={styles.settingSection}>
          <Text style={styles.sectionTitle}>Game Settings</Text>
          {gameSettings.map(renderSettingItem)}
        </View>

        {/* Account Settings */}
        <View style={styles.settingSection}>
          <Text style={styles.sectionTitle}>Account</Text>
          {accountSettings.map(renderSettingItem)}
        </View>

        {/* Support Settings */}
        <View style={styles.settingSection}>
          <Text style={styles.sectionTitle}>Support</Text>
          {supportSettings.map(renderSettingItem)}
        </View>

        {/* App Version */}
        <View style={styles.versionContainer}>
          <Text style={styles.versionText}>Legends Arena v1.0.0</Text>
          <Text style={styles.versionSubtext}>Made with ❤️ for mobile gamers</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 32,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 12,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.7)',
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
  },
  playerCard: {
    marginBottom: 32,
    borderRadius: 16,
    overflow: 'hidden',
  },
  playerCardGradient: {
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  playerAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  playerInfo: {
    flex: 1,
  },
  playerName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  playerLevel: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.9)',
    marginBottom: 2,
  },
  playerStats: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  settingSection: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 16,
    paddingLeft: 4,
  },
  settingItem: {
    marginBottom: 12,
    borderRadius: 12,
    overflow: 'hidden',
  },
  settingItemGradient: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(245, 158, 11, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
    marginBottom: 2,
  },
  settingDescription: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.6)',
  },
  navigationIndicator: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  navigationText: {
    fontSize: 20,
    color: 'rgba(255, 255, 255, 0.5)',
    fontWeight: '300',
  },
  versionContainer: {
    alignItems: 'center',
    paddingVertical: 32,
    marginBottom: 32,
  },
  versionText: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.6)',
    marginBottom: 4,
  },
  versionSubtext: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.5)',
  },
});