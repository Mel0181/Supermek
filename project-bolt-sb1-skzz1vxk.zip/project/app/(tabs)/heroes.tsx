import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Sword, Shield, Zap, Heart, Star, Lock } from 'lucide-react-native';

interface Hero {
  id: string;
  name: string;
  role: string;
  description: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  power: number;
  skills: string[];
  unlocked: boolean;
  image: string;
}

const heroes: Hero[] = [
  {
    id: '1',
    name: 'Dragon Slayer',
    role: 'Warrior',
    description: 'A mighty warrior with devastating melee attacks',
    rarity: 'legendary',
    power: 95,
    skills: ['Sword Strike', 'Battle Rage', 'Dragon Breath'],
    unlocked: true,
    image: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
  },
  {
    id: '2',
    name: 'Shadow Assassin',
    role: 'Assassin',
    description: 'Swift and deadly, strikes from the shadows',
    rarity: 'epic',
    power: 88,
    skills: ['Shadow Strike', 'Stealth', 'Poison Blade'],
    unlocked: true,
    image: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
  },
  {
    id: '3',
    name: 'Frost Mage',
    role: 'Mage',
    description: 'Controls ice magic with devastating spells',
    rarity: 'epic',
    power: 82,
    skills: ['Ice Shard', 'Frost Nova', 'Blizzard'],
    unlocked: false,
    image: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
  },
  {
    id: '4',
    name: 'Divine Healer',
    role: 'Support',
    description: 'Keeps allies alive with powerful healing magic',
    rarity: 'rare',
    power: 75,
    skills: ['Heal', 'Divine Shield', 'Resurrection'],
    unlocked: false,
    image: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
  },
  {
    id: '5',
    name: 'Storm Archer',
    role: 'Marksman',
    description: 'Long-range attacks with lightning-infused arrows',
    rarity: 'epic',
    power: 85,
    skills: ['Lightning Arrow', 'Rain of Arrows', 'Thunder Strike'],
    unlocked: false,
    image: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
  },
  {
    id: '6',
    name: 'Iron Guardian',
    role: 'Tank',
    description: 'Unbreakable defense with massive health',
    rarity: 'rare',
    power: 78,
    skills: ['Shield Bash', 'Taunt', 'Iron Will'],
    unlocked: true,
    image: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg',
  },
];

export default function HeroesScreen() {
  const [selectedHero, setSelectedHero] = useState<Hero | null>(null);
  const [filterRole, setFilterRole] = useState<string>('All');

  const roles = ['All', 'Warrior', 'Assassin', 'Mage', 'Support', 'Marksman', 'Tank'];

  const filteredHeroes = heroes.filter(hero => 
    filterRole === 'All' || hero.role === filterRole
  );

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'legendary':
        return ['#F59E0B', '#D97706'];
      case 'epic':
        return ['#8B5CF6', '#7C3AED'];
      case 'rare':
        return ['#3B82F6', '#2563EB'];
      default:
        return ['#6B7280', '#4B5563'];
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'Warrior':
        return <Sword size={20} color="white" />;
      case 'Assassin':
        return <Zap size={20} color="white" />;
      case 'Mage':
        return <Star size={20} color="white" />;
      case 'Support':
        return <Heart size={20} color="white" />;
      case 'Marksman':
        return <Zap size={20} color="white" />;
      case 'Tank':
        return <Shield size={20} color="white" />;
      default:
        return <Sword size={20} color="white" />;
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1E293B', '#0F172A']}
        style={styles.header}>
        <Text style={styles.headerTitle}>Heroes Collection</Text>
        <Text style={styles.headerSubtitle}>Choose your champion</Text>
      </LinearGradient>

      {/* Role Filter */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.filterContainer}>
        {roles.map((role) => (
          <TouchableOpacity
            key={role}
            style={[
              styles.filterButton,
              filterRole === role && styles.filterButtonActive,
            ]}
            onPress={() => setFilterRole(role)}>
            <Text style={[
              styles.filterText,
              filterRole === role && styles.filterTextActive,
            ]}>
              {role}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Heroes Grid */}
      <ScrollView style={styles.heroesContainer}>
        <View style={styles.heroesGrid}>
          {filteredHeroes.map((hero) => (
            <TouchableOpacity
              key={hero.id}
              style={styles.heroCard}
              onPress={() => setSelectedHero(hero)}>
              <LinearGradient
                colors={getRarityColor(hero.rarity)}
                style={styles.heroCardGradient}>
                
                {/* Hero Image */}
                <View style={styles.heroImageContainer}>
                  <Image
                    source={{ uri: hero.image }}
                    style={styles.heroImage}
                  />
                  {!hero.unlocked && (
                    <View style={styles.lockedOverlay}>
                      <Lock size={24} color="white" />
                    </View>
                  )}
                </View>

                {/* Hero Info */}
                <View style={styles.heroInfo}>
                  <View style={styles.heroHeader}>
                    <Text style={styles.heroName}>{hero.name}</Text>
                    <View style={styles.roleContainer}>
                      {getRoleIcon(hero.role)}
                    </View>
                  </View>
                  
                  <Text style={styles.heroRole}>{hero.role}</Text>
                  
                  <View style={styles.powerContainer}>
                    <Text style={styles.powerLabel}>Power</Text>
                    <View style={styles.powerBar}>
                      <View 
                        style={[
                          styles.powerFill,
                          { width: `${hero.power}%` }
                        ]} 
                      />
                    </View>
                    <Text style={styles.powerText}>{hero.power}</Text>
                  </View>

                  <View style={styles.rarityContainer}>
                    {[...Array(hero.rarity === 'legendary' ? 5 : 
                               hero.rarity === 'epic' ? 4 : 
                               hero.rarity === 'rare' ? 3 : 2)].map((_, i) => (
                      <Star key={i} size={12} color="#F59E0B" fill="#F59E0B" />
                    ))}
                  </View>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Hero Details Modal */}
      {selectedHero && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <LinearGradient
              colors={getRarityColor(selectedHero.rarity)}
              style={styles.modalHeader}>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setSelectedHero(null)}>
                <Text style={styles.closeButtonText}>✕</Text>
              </TouchableOpacity>
              
              <Image
                source={{ uri: selectedHero.image }}
                style={styles.modalHeroImage}
              />
              
              <Text style={styles.modalHeroName}>{selectedHero.name}</Text>
              <Text style={styles.modalHeroRole}>{selectedHero.role}</Text>
              
              <View style={styles.modalRarityContainer}>
                {[...Array(selectedHero.rarity === 'legendary' ? 5 : 
                           selectedHero.rarity === 'epic' ? 4 : 
                           selectedHero.rarity === 'rare' ? 3 : 2)].map((_, i) => (
                  <Star key={i} size={16} color="#F59E0B" fill="#F59E0B" />
                ))}
              </View>
            </LinearGradient>

            <View style={styles.modalBody}>
              <Text style={styles.modalDescription}>
                {selectedHero.description}
              </Text>

              <View style={styles.skillsSection}>
                <Text style={styles.skillsTitle}>Skills</Text>
                {selectedHero.skills.map((skill, index) => (
                  <View key={index} style={styles.skillItem}>
                    <View style={styles.skillIcon}>
                      {getRoleIcon(selectedHero.role)}
                    </View>
                    <Text style={styles.skillName}>{skill}</Text>
                  </View>
                ))}
              </View>

              <TouchableOpacity
                style={[
                  styles.selectButton,
                  !selectedHero.unlocked && styles.selectButtonDisabled,
                ]}
                disabled={!selectedHero.unlocked}>
                <LinearGradient
                  colors={selectedHero.unlocked ? 
                    ['#10B981', '#059669'] : 
                    ['#6B7280', '#4B5563']}
                  style={styles.selectButtonGradient}>
                  <Text style={styles.selectButtonText}>
                    {selectedHero.unlocked ? 'SELECT HERO' : 'LOCKED'}
                  </Text>
                  {!selectedHero.unlocked && (
                    <Lock size={16} color="white" style={styles.selectButtonIcon} />
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 24,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.7)',
  },
  filterContainer: {
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  filterButton: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    marginRight: 12,
  },
  filterButtonActive: {
    backgroundColor: '#F59E0B',
  },
  filterText: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 14,
    fontWeight: '500',
  },
  filterTextActive: {
    color: 'white',
    fontWeight: 'bold',
  },
  heroesContainer: {
    flex: 1,
    paddingHorizontal: 16,
  },
  heroesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  heroCard: {
    width: '48%',
    marginBottom: 16,
    borderRadius: 12,
    overflow: 'hidden',
  },
  heroCardGradient: {
    padding: 12,
  },
  heroImageContainer: {
    position: 'relative',
    height: 120,
    borderRadius: 8,
    overflow: 'hidden',
    marginBottom: 12,
  },
  heroImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  lockedOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroInfo: {
    flex: 1,
  },
  heroHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  heroName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    flex: 1,
  },
  roleContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroRole: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.8)',
    marginBottom: 8,
  },
  powerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  powerLabel: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.8)',
    width: 40,
  },
  powerBar: {
    flex: 1,
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
    marginHorizontal: 8,
  },
  powerFill: {
    height: '100%',
    backgroundColor: 'white',
    borderRadius: 2,
  },
  powerText: {
    fontSize: 12,
    color: 'white',
    fontWeight: 'bold',
    width: 30,
    textAlign: 'right',
  },
  rarityContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  modalContent: {
    backgroundColor: '#1E293B',
    borderRadius: 16,
    width: '100%',
    maxWidth: 400,
    overflow: 'hidden',
  },
  modalHeader: {
    padding: 24,
    alignItems: 'center',
    position: 'relative',
  },
  closeButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalHeroImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  modalHeroName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  modalHeroRole: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
    marginBottom: 12,
  },
  modalRarityContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  modalBody: {
    padding: 24,
  },
  modalDescription: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
    lineHeight: 24,
    textAlign: 'center',
    marginBottom: 24,
  },
  skillsSection: {
    marginBottom: 24,
  },
  skillsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 16,
  },
  skillItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  skillIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(245, 158, 11, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  skillName: {
    fontSize: 16,
    color: 'white',
    fontWeight: '500',
  },
  selectButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  selectButtonDisabled: {
    opacity: 0.6,
  },
  selectButtonGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectButtonIcon: {
    marginLeft: 8,
  },
});